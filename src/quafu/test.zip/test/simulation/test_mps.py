from quafu import QuantumCircuit, simulate
import numpy as np
from random import choices
from vidal_mps import VidalMPS
import matplotlib.pyplot as plt
import time


def rand_theta():
    return np.random.randn() * 2 * np.pi


n = 136
pos_list = list(range(n))
qc = QuantumCircuit(n)


for i in range(23):
    p = choices(pos_list, k=1)[0]
    qc.rx(p, rand_theta())
    p = choices(pos_list, k=1)[0]
    qc.ry(p, rand_theta())
    p1, p2 = choices(pos_list, k=2)
    if p1 != p2:
        qc.cnot(p1, p2)
#     p1, p2 = choices(pos_list, k=2)
#     if p1 != p2:
#         qc.cnot(p1, p2)
#     p1, p2 = choices(pos_list, k=2)
#     if p1 != p2:
#         qc.cnot(p1, p2)
#     p1, p2 = choices(pos_list, k=2)
#     if p1 != p2:
#         qc.cnot(p1, p2)
#     p1, p2 = choices(pos_list, k=2)
#     if p1 != p2:
#         qc.cnot(p1, p2)
#     p1, p2 = choices(pos_list, k=2)
#     if p1 != p2:
#         p1, p2 = min(p1, p2), max(p1, p2)
#         qc.cnot(p1, p2)
#     p = choices(pos_list, k=1)[0]
#     qc.ry(p, rand_theta())
#     qc.rz(*choices(pos_list, k=1), rand_theta())
#     p1, p2 = choices(pos_list, k=2)
#     if p1 != p2:
#         qc.cnot(p1, p2)
#
#     # qc.rz(*choices(pos_list, k=1), rand_theta())
#     # qc.rx(*choices(pos_list, k=1), rand_theta())

qc.ry(1, np.pi/4)
qc.cnot(0, n-1)


print('qc built')
# for gate in qc.gates:
#     if gate.name == 'CX':
#         print(gate.pos, gate.targs, gate.ctrls)
qc.plot_circuit(title='simulation test')
plt.savefig('qc.png')
print('plot finished')

# start = time.time()
# result = simulate(qc, output='state_vector')
# end = time.time()

# exa_prob = result.state_vector * result.state_vector.conj()
# print(f'exact simulation time: {end - start:.6f}s')

mps = VidalMPS(chi=10, n=n, verbose=True)
start = time.time()
mps(qc)
end = time.time()
print(f'mps simulation time: {end - start:.6f}s')
# mps_state = mps.to_state_tensor().transpose(list(range(n)[::-1]))
# mps_vec = mps_state.reshape(-1)
# print('exact vec:', result.state_vector)
# print('mps_vec:', mps_vec)

# mps_prob = mps_vec * mps_vec.conj()

# print('mps error=', np.linalg.norm(exa_prob-mps_prob))
