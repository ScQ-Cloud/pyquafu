import warnings
from numpy.linalg.linalg import eig, svd

import numpy as np

import quafu.elements.matrices as mat
import quafu.elements.element_gates as qeg
from quafu.elements.quantum_gate import SingleQubitGate
from quafu import QuantumCircuit

XCMatrix = mat.SwapMatrix @ mat.CXMatrix @ mat.SwapMatrix

"""
Numpy implementation of Vidal MPS protocol for quantum circuit simulation,
proposed by Guifre´ Vidal in 2003, https://arxiv.org/pdf/quant-ph/0301063.pdf.
"""


class VidalMPS:
    """ Numpy implementation of Vidal MPS protocol for quantum circuit simulation,
    proposed by Guifre´ Vidal in 2003, https://arxiv.org/pdf/quant-ph/0301063.pdf.

    The algorithm represent state of qubits as (contraction of) a series of the following
    tensors:

       i_0               i_1               i_2             ...                i_{n-1}
        |                 |                 |              ...                  |
     Gamma_0--lambda0--Gamma_1--lambda1--Gamma_2--lambda2--...--lambda_{n-1}--Gamma_{n-1}

    Virtue of this representation is that it can be efficiently updated when applying
    1-qubit and 2-qubit gate. The bond-dimension between gamma and lambda can be determined
    by Schmidt decomposition. Practically, in order to reduce the computational cost, we set
    a maximum bond-dimension chi, and truncate the bond-dimension if it exceeds chi. The
    truncation introduces a truncation error, which can be indicated by the sum of truncated
    singular values.
    """

    def __init__(self, chi: int, n: int, verbose: bool = False):
        self.chi = chi
        self.n = n
        self.verbose = verbose

        # init as |0000...> state by default
        self.gammas, self.lambdas = self.init_tensors()

    def init_tensors(self, psi: np.ndarray = None):
        """Initialize vidal's MPS tensors for given state.

        Support only |0000...> state for now.
        """
        if psi:
            raise NotImplementedError
        else:
            gamma_tensor = np.zeros((1, 2, 1), dtype=complex)
            gamma_tensor[0, 0, 0] = 1.
            gammas = [gamma_tensor.copy() for _ in range(self.n)]
            lambdas = [np.ones(1, dtype=float) for _ in range(self.n - 1)]
            return gammas, lambdas

    def __call__(self, qc: QuantumCircuit, *args, **kwargs):
        for gate in qc.gates:
            if isinstance(gate, SingleQubitGate):
                self.apply_su2(gate.matrix, gate.pos)
            elif isinstance(gate, qeg.CXGate):
                self.apply_cnot(gate.ctrls[0], gate.targs[0])
            else:
                raise NotImplementedError
        # TODO: type check and extract matrices from gates
        pass

    def apply_su2(self, matrix: np.ndarray, pos: int):
        """ Apply 1-qubit gate to the pos-th qubit. """
        gamma_tensor = self.gammas[pos]
        chi1, _, chi2 = gamma_tensor.shape
        gamma_tensor = np.tensordot(gamma_tensor, matrix, axes=([1], [1]))
        assert gamma_tensor.shape == (chi1, chi2, 2)
        gamma_tensor = gamma_tensor.transpose((0, 2, 1))
        self.gammas[pos] = gamma_tensor

    def apply_su4(self, matrix: np.ndarray, p1: int, p2: int):
        """ Apply 2-qubit gate to the p1-th and p2-th qubits. """
        p1, p2 = min(p1, p2), max(p1, p2)
        if not 0 <= p1 < p2 < self.n:
            raise ValueError("Invalid qubit indices: %d, %d", (p1, p2))

        # swap to make p1-th and p2-th qubits adjacent
        for p in range(p1, p2 - 1):
            self.apply_consecutive_swap(p)

        self._apply_consecutive_su4(matrix, p2 - 1)

        # swap back
        for p in range(p2 - 2, p1 - 1, -1):
            self.apply_consecutive_swap(p)

    def apply_consecutive_swap(self, pos: int):
        """ Apply SWAP to the pos-th and (pos + 1)-th qubits. """
        # TODO: optimize
        self._apply_consecutive_su4(mat.SwapMatrix, pos)

    def apply_cnot(self, p1: int, p2: int):
        """ Apply CNOT to the p1-th and p2-th qubits. """
        # TODO: optimize
        if p1 < p2:
            self.apply_su4(mat.CXMatrix, p1, p2)
        elif p1 > p2:
            self.apply_su4(XCMatrix, p2, p1)
        else:
            raise ValueError("Invalid qubit indices: %d, %d", (p1, p2))

    def _apply_consecutive_su4(self, theta_matrix: np.ndarray, pos: int, debug: bool = False):
        """ Apply 2-qubit gate to the pos-th and (pos + 1)-th qubits.

        Args:
            theta_matrix: 4x4 matrix of the gate.
        This is the main computation-consuming part.
        """
        if not theta_matrix.shape == (4, 4):
            raise ValueError("Invalid shape of theta matrix: %s", theta_matrix.shape)
        else:
            theta_matrix = theta_matrix.copy().reshape((2, 2, 2, 2))

        gamma_1, gamma_2 = self.gammas[pos], self.gammas[pos + 1]
        lambda_ = self.lambdas[pos]

        chi1, chi0, chi2 = gamma_1.shape[0], lambda_.shape[0], gamma_2.shape[2]
        assert chi0 == gamma_1.shape[2] == gamma_2.shape[0]

        block_ = gamma_1 * lambda_.reshape((1, 1, chi0))  # shape: (chi1, 2, chi0)
        assert block_.shape == (chi1, 2, chi0)
        block_ = np.tensordot(block_, theta_matrix, axes=([1], [2]))  # shape: (chi1, chi0, 2, 2, 2)
        assert block_.shape == (chi1, chi0, 2, 2, 2)
        block_ = np.tensordot(block_, gamma_2, axes=([1, 4], [0, 1]))  # shape: (chi1, 2, 2, chi2)
        assert block_.shape == (chi1, 2, 2, chi2)

        # note: svd does not ensure the gauge of global phase
        u, s_exact, vh = svd(block_.reshape(2 * chi1, 2 * chi2), full_matrices=False)

        # check:
        if debug:
            _ = (u * s_exact) @ vh
            print('invariant after SVD:', np.allclose(_.reshape(chi1, 2, 2, chi2), block_))

        chi = min(self.chi, len(s_exact))
        order = np.argsort(s_exact)[::-1][:chi]  # descending order

        s = s_exact[order]
        u, vh = u[:, order], vh[order, :]

        error = np.linalg.norm(np.sort(s_exact)[::-1][chi:]) / np.linalg.norm(s_exact)
        if self.verbose:
            if error > 1e-12:
                print("Truncation error: ", error)

        self.lambdas[pos] = s
        self.gammas[pos] = u.reshape(chi1, 2, chi)
        self.gammas[pos + 1] = vh.reshape(chi, 2, chi2)

    def to_state_tensor(self):
        """ Transform matrices into state tensor, shape = (2, 2, ..., 2). """
        if self.n > 12:
            warnings.warn("The number of qubits is too large, "
                          "it may cost too much memory space.")
        state_tensor = self.gammas[0].copy()
        state_tensor = state_tensor.reshape((2, -1))
        for i in range(1, self.n):
            state_tensor *= self.lambdas[i - 1]
            gamma_tensor = self.gammas[i].copy()
            if i == self.n - 1:
                gamma_tensor = gamma_tensor.reshape(-1, 2)
            state_tensor = np.tensordot(state_tensor, gamma_tensor, axes=([-1], [0]))

        assert state_tensor.shape == (2,) * self.n
        # TODO: fix gauge of global phase?
        return state_tensor


if __name__ == '__main__':
    def check_state(which: tuple):
        state = mps.to_state_tensor()
        print('|psi|:', np.linalg.norm(state))
        print(state.shape)
        print(state.reshape(-1))
        print('|%s> =' % ''.join(map(str, which)), state[which])
        print(flush=True)


    mps = VidalMPS(chi=10, n=3)
    mps.apply_su2(mat.XMatrix, 0)
    check_state((1, 0, 0))

    mps.apply_su4(mat.SwapMatrix, 0, 1)

    check_state((0, 1, 0))

    mps.apply_su4(mat.CXMatrix, 1, 2)
    check_state((0, 1, 1))

    mps.apply_su4(mat.SwapMatrix, 0, 1)
    check_state((1, 0, 1))

    mps.apply_su4(mat.CXMatrix, 0, 2)
    check_state((1, 0, 0))
