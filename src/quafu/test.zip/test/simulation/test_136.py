from vidal_mps import VidalMPS

n = 136
mps = VidalMPS(chi=10, n=n)
