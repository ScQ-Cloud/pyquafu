from quafu import QuantumCircuit, simulate, Task
import matplotlib.pyplot as plt

# initialization
qc = QuantumCircuit(1)

# apply gate(s)
qc.h(0)

# measure
qc.measure([0])

# draw
qc.draw_circuit()

# save circuits
f = open('openqasm.txt', 'w')
f.write(qc.to_openqasm())
f.close()

# load circuits
f = open('openqasm.txt', 'r')
qasm_code = f.read()
qc2 = QuantumCircuit(1)
qc2.from_openqasm(qasm_code)

# simulate
simu_res = simulate(qc)
print(f'simulation results =  {simu_res.probabilities}')
simu_res.plot_probabilities()
plt.title('Measurement of Hadamard Gate')
plt.show()

# execute task
task = Task()


