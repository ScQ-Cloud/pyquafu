from all_members import all_gates

from pprint import pp
import copy
from typing import Iterable

bit_mapping = {0: 3, 1: 2, 2: 5, 3: 9}

copies = []


def map_pos(pos):
    if isinstance(pos, int):
        return bit_mapping[pos]
    elif isinstance(pos, Iterable):
        return [bit_mapping[p] for p in pos]
    else:
        raise ValueError


for gate in all_gates:
    gate_ = copy.deepcopy(gate)
    for key, val in gate.named_pos.items():
        setattr(gate_, key, map_pos(val))
    setattr(gate_, 'pos', map_pos(gate.pos))
    pp(gate_.named_pos)
    print(gate_.pos)
