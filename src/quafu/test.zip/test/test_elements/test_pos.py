import quafu.elements.element_gates as qeg

cp = qeg.CPGate(ctrl=0, targ=1, paras=0)
cp.named_pos['ctrls'] = [2]
print(cp.ctrls)
