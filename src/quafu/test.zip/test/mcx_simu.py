from quafu import QuantumCircuit, simulate, Task

qc = QuantumCircuit(3)
qc.x(0)
qc.x(1)
qc.mcx([0, 1], 2)
qc.measure()
# qc.draw_circuit()
# qc.plot_circuit(show=True, title='mcx-test')
print(qc.to_openqasm())
simu_res = simulate(qc, output="probabilities")  # , simulator='py_simu'
simu_res.plot_probabilities()

task = Task()
task.config(backend="ScQ-P18")
res = task.send(qc)
# res.transpiled_circuit.plot_circuit(show=True, title='mcx-test')
print(res.transpiled_openqasm)
