from quafu import User

user = User()
user.save_apitoken('UbLaSyVJXU1C3yzm-J4E68YBOM3uaDMomcef6b2VYp2.9RDO0czN1IDO2EjOiAHelJCL3kDN6ICZpJye.9JiN1IzUIJiOicGbhJCLiQ1VKJiOiAXe0Jye')
