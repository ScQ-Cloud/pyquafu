from quafu import QuantumCircuit, Task
import numpy as np
import matplotlib.pyplot as plt


def main():
    num = 18
    qc = QuantumCircuit(num)
    # for i in range(num):
    #     qc.rx(i, np.pi * np.random.random())
    #     if i // 3 == 0:
    #         qc.cnot(i, i+1)
    qc.measure()

    # execute task
    task = Task()
    task.config(backend='ScQ-P%d' % num, shots=20000)
    res = task.send(qc)

    counts = [[bit_str] * count for bit_str, count in res.counts.items()]
    strings = list()
    for sec in counts:
        strings += sec

    data = np.array([list(map(int, bit_str)) for bit_str in strings], dtype=int)

    print(data.dtype)

    # 计算协方差矩阵
    cov_matrix = np.cov(data, rowvar=False)  # 设置rowvar=False表示每列是一个变量
    np.fill_diagonal(cov_matrix, 0)
    cov_matrix = np.abs(cov_matrix)

    # 绘制热图
    plt.style.use('seaborn-v0_8-bright')
    plt.imshow(cov_matrix,
               cmap='Greens',  # Blues, Greens
               interpolation='nearest',
               origin='lower')
    plt.xticks(range(0, num, 1 + 19 * (num > 18)))
    plt.yticks(range(0, num, 1 + 19 * (num > 18)))

    # 添加颜色条
    plt.colorbar()

    plt.title('Covariance Matrix Heatmap')
    plt.show()
    plt.close()


if __name__ == '__main__':
    for i in range(10):
        main()
