from quafu import QuantumCircuit, Task, User

qc = QuantumCircuit(2)
qc.xy(0, 1, 30)
print(qc.gates[0].pos)

user = User()
user.get_available_backends()
task = Task()
task.config(backend='ScQ-P10', shots=9, compile=False)
res = task.send(qc)
print(res.counts)
