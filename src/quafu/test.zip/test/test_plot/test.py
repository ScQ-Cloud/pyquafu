from quafu.visualisation.newCircuitPlot import CircuitPlotManager

