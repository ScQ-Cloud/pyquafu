import quafu.elements as qe

barrier = qe.Barrier([0])
