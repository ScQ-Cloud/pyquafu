from quantum_circuit import QuantumCircuit
 
def from_openqa