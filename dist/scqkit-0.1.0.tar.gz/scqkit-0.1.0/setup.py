from setuptools import find_packages, setup 

setup(name="scqkit",
    version="0.1.0",
    description="Python toolkit for ScQ-Clound",
    author="ssli",
    author_email="ssli@iphy.ac.cn",
    install_requires=["numpy", "matplotlib", "qutip"],
    packages=find_packages('src'),
    package_dir={'':'src'},
    include_package_data=True,
    zip_safe=False,
    setup_cfg=True,
    license="apache 3.0"
)